const { chromium } = require('playwright'); const fs=require('fs');
(async()=>{ const b=await chromium.launch(); const pg=await b.newPage({viewport:{width:1300,height:800}}); const errs=[]; pg.on('pageerror',e=>errs.push(e.message));
 await pg.goto('file:///home/claude/work/app/index.html'); await pg.waitForTimeout(800);
 await pg.evaluate(s=>{ app.importDocs(s); selKy='2026-10'; view='tongquan'; render(); }, JSON.parse(fs.readFileSync('/home/claude/work/seed.json','utf8')));
 await pg.screenshot({path:'/home/claude/work/shots/tq.png'});
 await pg.click('a[data-go="giathanh"]'); await pg.waitForTimeout(300);
 console.log(await pg.evaluate(()=>[view, document.querySelector('#main .tabs .act')?.textContent]), errs); await b.close(); })();
