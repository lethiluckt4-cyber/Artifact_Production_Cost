const { chromium } = require('playwright'); const fs=require('fs');
(async()=>{ const b=await chromium.launch(); const ctx=await b.newContext({acceptDownloads:true}); const pg=await ctx.newPage({viewport:{width:1400,height:900}}); const errs=[]; pg.on('pageerror',e=>errs.push(e.message));
 await pg.goto('file:///home/claude/work/app/index.html'); await pg.waitForTimeout(800);
 await pg.evaluate(s=>{ app.importDocs(s); selKy='2026-10'; view='canhbao'; render(); }, JSON.parse(fs.readFileSync('/home/claude/work/seed.json','utf8')));
 const [dl]=await Promise.all([pg.waitForEvent('download',{timeout:15000}), pg.click('#cbXl')]); await dl.saveAs('/tmp/cb.xlsx'); console.log(dl.suggestedFilename(), errs); await b.close(); })();
